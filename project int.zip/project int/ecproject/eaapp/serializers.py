from rest_framework import serializers
from .models import customer,product

class custserializer(serializers.ModelSerializer):
    class Meta:
        model=customer
        fields='__all__'

class prodectserializer(serializers.ModelSerializer):
    class Meta:
        model=product
        fields='__all__'