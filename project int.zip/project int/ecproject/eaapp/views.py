from django.shortcuts import render
from django.http import HttpResponse
from .models import customer,product


# Create your views here.
# def hello(request):
#     return HttpResponse("welcome to django")

from rest_framework import viewsets
from .serializers import custserializer,prodectserializer


class custviewset(viewsets.ModelViewSet):
    queryset=customer.objects.all()
    serializer_class=custserializer
    print(serializer_class)

# def get_second_dropdown_data(request):
#     queryset=customer.objects.all()
#     serializer=custserializer(queryset,many=True)
#     # print(serializer.data)
#     context={'data':serializer.data}
#     return render(request,'table.html',context)

class productviewset(viewsets.ModelViewSet):
    queryset=product.objects.all()
    serializer_class=prodectserializer
    print(serializer_class)

